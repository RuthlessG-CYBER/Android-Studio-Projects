package com.example.cameraapp

import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import coil.compose.rememberAsyncImagePainter
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

@Composable
fun PermissionScreen() {
    val context = LocalContext.current
    val permissions = listOf(
        android.Manifest.permission.CAMERA,
        android.Manifest.permission.RECORD_AUDIO
    )
    val isGranted = remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { result ->
            isGranted.value = result[android.Manifest.permission.CAMERA] == true &&
                    result[android.Manifest.permission.RECORD_AUDIO] == true
        }
    )


    LaunchedEffect(Unit) {
        isGranted.value = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
    }

    if (isGranted.value) {
        CameraScreen()
    } else {
        Box(
            modifier = Modifier.fillMaxSize().background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            OutlinedButton(onClick = { launcher.launch(permissions.toTypedArray()) }) {
                Text(text = "Request Permission")
            }
        }
    }
}

@Composable
fun CameraScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView: PreviewView = remember { PreviewView(context) }
    val imageCapture = remember { ImageCapture.Builder().build() }
    var cameraSelector by remember { mutableStateOf(CameraSelector.DEFAULT_BACK_CAMERA) }
    var latestImageUri by remember { mutableStateOf<String?>(null) }  // Added state for image URI
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri ->
            uri?.let {
                Toast.makeText(context, "Selected: $uri", Toast.LENGTH_SHORT).show()
            }
        }
    )

    LaunchedEffect(cameraSelector) {
        val cameraProvider = context.getCameraProvider()
        val preview = androidx.camera.core.Preview.Builder().build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        try {
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
                lifecycleOwner,
                cameraSelector,
                preview,
                imageCapture
            )
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to initialize camera: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomCenter
    ) {
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.7f))
                .padding(30.dp)
        ) {
            IconButton(
                onClick = {
                    galleryLauncher.launch("image/*")
                },
                modifier = Modifier.size(40.dp).align(Alignment.CenterStart)
            ) {
                val painter = latestImageUri?.let {
                    rememberAsyncImagePainter(model = it)
                } ?: painterResource(id = android.R.drawable.ic_menu_gallery)
                Icon(
                    painter = painter,
                    contentDescription = "Open Gallery",
                    tint = Color.Unspecified,
                    modifier = Modifier.size(40.dp)
                )
            }
            IconButton(
                onClick = {
                    capturePhoto(imageCapture, context) { uri ->
                        latestImageUri = uri // Update the URI after photo capture
                    }
                },
                modifier = Modifier.size(64.dp)
                    .align(Alignment.Center)
                    .background(Color.White.copy(alpha = 0.2f), CircleShape)
                    .padding(2.dp)
                    .background(Color.Yellow, CircleShape)
                    .padding(1.dp)
                    .background(Color.Black, CircleShape)
            ){}
            IconButton(
                onClick = {
                    cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }
                },
                modifier = Modifier.align(Alignment.CenterEnd)
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Switch Camera",
                    tint = Color.White, modifier = Modifier.size(40.dp))
            }
        }
    }
}

suspend fun Context.getCameraProvider(): ProcessCameraProvider = suspendCoroutine { continuation ->
    val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

    cameraProviderFuture.addListener({
        try {
            continuation.resume(cameraProviderFuture.get())
        } catch (e: Exception) {
            continuation.resumeWith(Result.failure(e))
        }
    }, ContextCompat.getMainExecutor(this))
}

private fun capturePhoto(imageCapture: ImageCapture, context: Context, onImageCaptured: (String) -> Unit) {
    val name = "MyCamera_${System.currentTimeMillis()}.jpg"

    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MyCamera-Images")
    }

    val outputOptions = ImageCapture.OutputFileOptions.Builder(
        context.contentResolver,
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        contentValues
    ).build()

    imageCapture.takePicture(
        outputOptions,
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                val uri = outputFileResults.savedUri.toString()
                Toast.makeText(context, "Photo Captured: $uri", Toast.LENGTH_SHORT).show()
                onImageCaptured(uri) // Callback to update the latest image URI
            }

            override fun onError(exception: ImageCaptureException) {
                Toast.makeText(context, "Failed to Capture: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
        }
    )
}

